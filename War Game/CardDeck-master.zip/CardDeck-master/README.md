# CardDeck
Deck of cards for the game of war

# TODO
1. //TODO: Shuffle deck
2. //TODO: Deal cards to player decks
3. //TODO: Add menus to play the game of war
