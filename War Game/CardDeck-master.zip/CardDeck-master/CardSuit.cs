namespace CardDeck
{
    public enum CardSuit
    {
        Hearts = 1,
        Diamonds,
        Clubs,
        Spades
    }
}